<template>
	<div>
		注册组件页面
	</div>
</template>

<script>
export default {};
</script>

<style scoped>

</style>