```html
<!DOCTYPE html>
<html lang="en">
<head
    <meta charset="utf-8">
    <title>Hi!</title>
</head>
<body>
    <p>Hello, world!</p>
</body>
</html>
```

~~~~~~java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
~~~~~~

```sql
SELECT "Hello, world!" FROM DUMMY -- Hello, world!
SELECT "Hello, world!" FROM DUMMY -- Hello, world!
```
