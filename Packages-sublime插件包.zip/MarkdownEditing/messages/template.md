# MarkdownEditing {version} Changelog

Your _MarkdownEditing_ plugin is updated. Enjoy new version. For any type of
feedback you can use [GitHub issues][issues].

## Bug Fixes

## New Features

## Changes

[issues]: https://github.com/SublimeText-Markdown/MarkdownEditing/issues
