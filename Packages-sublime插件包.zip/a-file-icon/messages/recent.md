# A File Icon 3.2.1

New release!

Please see `Tools → Packages → A File Icon → Changelog` for more info about 
the release.

***

I've put a lot of time and effort into making `A File Icon` awesome. If you 
love it, you can [buy me a coffee](https://www.patreon.com/ihodev) ☕.
